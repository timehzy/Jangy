// ─────────────────────────────────────────────────────────────
// 调研数据层 · 数据采集时间 2026-09-28
// 仓库指标来自 GitHub API 实时查询，功能信息来自各仓库 README / Wiki / 官方文档
// ─────────────────────────────────────────────────────────────

export type MaintenanceStatus = 'active' | 'slow' | 'dormant' | 'dead' | 'sunset'
export type Category = 'core' | 'render' | 'ui' | 'capture' | 'picker'

export interface Repo {
  id: string
  name: string
  owner: string
  url: string
  category: Category
  desc: string
  stars: number
  language: string
  license: string
  created: string // ISO date
  lastPush: string // ISO date
  minOS: string
  platforms: string
  status: MaintenanceStatus
  role: string // 一句话定位
}

export const REPOS: Repo[] = [
  {
    id: 'kadr', name: 'Kadr', owner: 'SteliyanH/kadr', url: 'https://github.com/SteliyanH/kadr',
    category: 'core', desc: '声明式视频合成 DSL，基于 AVFoundation，result-builder + async/await，零三方依赖',
    stars: 56, language: 'Swift', license: 'Apache-2.0', created: '2026-04-22', lastPush: '2026-09-01',
    minOS: 'iOS 17 / macOS 14 / tvOS 17 / visionOS 1', platforms: 'iOS · macOS · tvOS · visionOS',
    status: 'active', role: '新锐首选：引擎与 UI 分离的全家桶',
  },
  {
    id: 'cabbage', name: 'Cabbage', owner: 'VideoFlint/Cabbage', url: 'https://github.com/VideoFlint/Cabbage',
    category: 'core', desc: 'Timeline/Resource/TrackItem 抽象的视频合成框架，API 简洁、可扩展',
    stars: 1578, language: 'Swift', license: 'MIT', created: '2018-08-01', lastPush: '2023-11-08',
    minOS: 'iOS 9+', platforms: 'iOS',
    status: 'dormant', role: '经典设计：时间线内核的保守选择',
  },
  {
    id: 'videolab', name: 'VideoLab', owner: 'ruanjx/VideoLab', url: 'https://github.com/ruanjx/VideoLab',
    category: 'core', desc: 'AE 式图层模型 + Metal 自定义合成器，支持关键帧动画与预合成',
    stars: 921, language: 'Swift', license: 'MIT', created: '2021-02-21', lastPush: '2022-10-31',
    minOS: 'iOS 11+', platforms: 'iOS',
    status: 'dead', role: '设计蓝本：适合作为自研架构参考',
  },
  {
    id: 'vek', name: 'VideoEditorKit', owner: 'didisouzacosta/VideoEditorKit', url: 'https://github.com/didisouzacosta/VideoEditorKit',
    category: 'core', desc: 'SwiftUI 开箱即用编辑器，可序列化编辑状态，iOS 18.6+ / Swift 6',
    stars: 19, language: 'Swift', license: 'MIT', created: '2026-04-02', lastPush: '2026-04-30',
    minOS: 'iOS 18.6+', platforms: 'iOS（iPhone）',
    status: 'active', role: '观察项：门槛过高、功能尚浅',
  },
  {
    id: 'metalpetal', name: 'MetalPetal', owner: 'MetalPetal/MetalPetal', url: 'https://github.com/MetalPetal/MetalPetal',
    category: 'render', desc: 'Metal 图像/视频处理引擎，惰性渲染图 + 100+ 内置滤镜 + MTTransitions 转场',
    stars: 2190, language: 'Obj-C / Swift API', license: 'MIT', created: '2017-06-25', lastPush: '2024-04-10',
    minOS: 'iOS 11+', platforms: 'iOS · macOS · tvOS',
    status: 'dormant', role: '滤镜引擎事实标准（原作者已失联）',
  },
  {
    id: 'raster', name: 'Raster', owner: 'aldealabs/raster', url: 'https://github.com/aldealabs/raster',
    category: 'render', desc: 'MetalPetal 的官方接续 fork，保留 MTI* API，HDR/广色域为发展重点',
    stars: 11, language: 'Obj-C / Swift API', license: 'MIT', created: '2026-08-15', lastPush: '2026-08-15',
    minOS: 'iOS 12+', platforms: 'iOS · macOS · tvOS · Catalyst',
    status: 'active', role: '滤镜引擎的维护延续（视频非其重点）',
  },
  {
    id: 'gpuimage3', name: 'GPUImage 3', owner: 'BradLarson/GPUImage3', url: 'https://github.com/BradLarson/GPUImage3',
    category: 'render', desc: '老牌 Metal 滤镜链框架，PixelSDK 的底层渲染依赖',
    stars: 2876, language: 'Swift', license: 'BSD-3-Clause', created: '2018-06-17', lastPush: '2024-07-25',
    minOS: 'iOS 9+', platforms: 'iOS · macOS · Linux',
    status: 'dormant', role: '可用但更新缓慢的传统选项',
  },
  {
    id: 'bbmetal', name: 'BBMetalImage', owner: 'Silence-GitHub/BBMetalImage', url: 'https://github.com/Silence-GitHub/BBMetalImage',
    category: 'render', desc: 'GPUImage 风格的纯 Swift Metal 滤镜库，80+ 内置滤镜',
    stars: 1041, language: 'Swift', license: 'MIT', created: '2019-04-20', lastPush: '2022-10-10',
    minOS: 'iOS 10+', platforms: 'iOS',
    status: 'dead', role: '已停更，不建议新项目采用',
  },
  {
    id: 'prynt', name: 'PryntTrimmerView', owner: 'HHK1/PryntTrimmerView', url: 'https://github.com/HHK1/PryntTrimmerView',
    category: 'ui', desc: '纯 UI 组件：视频裁剪时间轴 + 画幅裁切视图，不含处理逻辑',
    stars: 907, language: 'Swift', license: 'MIT', created: '2017-03-28', lastPush: '2024-12-11',
    minOS: 'iOS 9+', platforms: 'iOS',
    status: 'slow', role: 'UIKit 裁剪 UI 的成熟零件',
  },
  {
    id: 'nextlevel', name: 'NextLevel', owner: 'NextLevel/NextLevel', url: 'https://github.com/NextLevel/NextLevel',
    category: 'capture', desc: 'AVFoundation 拍摄封装：分段录制、慢动作、自定义编码配置',
    stars: 2332, language: 'Swift', license: 'MIT', created: '2015-03-24', lastPush: '2026-06-08',
    minOS: 'iOS 11+', platforms: 'iOS',
    status: 'active', role: '若 App 含拍摄功能的首选',
  },
  {
    id: 'screcorder', name: 'SCRecorder', owner: 'rFlex/SCRecorder', url: 'https://github.com/rFlex/SCRecorder',
    category: 'capture', desc: 'Vine 式点按录制 + 分段编辑相机引擎（Objective-C 时代遗物）',
    stars: 3037, language: 'Objective-C', license: 'Apache-2.0', created: '2013-08-05', lastPush: '2021-05-25',
    minOS: 'iOS 7+', platforms: 'iOS',
    status: 'dead', role: '已停更 5 年，仅具历史价值',
  },
  {
    id: 'yp picker', name: 'YPImagePicker', owner: 'Yummypets/YPImagePicker', url: 'https://github.com/Yummypets/YPImagePicker',
    category: 'picker', desc: 'Instagram 式素材选择器，自带简单裁剪与滤镜，非剪辑内核',
    stars: 4483, language: 'Swift', license: 'MIT', created: '2017-07-19', lastPush: '2026-07-28',
    minOS: 'iOS 12+', platforms: 'iOS',
    status: 'active', role: '素材导入环节的现成轮子',
  },
]

// ── 功能覆盖矩阵 ─────────────────────────────────────────────
export type Coverage = 'yes' | 'partial' | 'no'

export interface FeatureRow {
  feature: string
  cells: Record<'kadr' | 'cabbage' | 'videolab' | 'vek', { level: Coverage; note: string }>
}

export const FEATURE_MATRIX: FeatureRow[] = [
  {
    feature: '多段视频拼接 / 裁剪',
    cells: {
      kadr: { level: 'yes', note: 'VideoClip.trimmed(to:) + 多轨 DSL，裁剪范围闭区间语义清晰' },
      cabbage: { level: 'yes', note: 'Timeline 双通道（videoChannel / audioChannel），TrackItem 自由排布' },
      videolab: { level: 'yes', note: 'RenderLayer 以 timeRange 描述，多段拼接是基本用法' },
      vek: { level: 'no', note: '仅支持单个本地视频的裁剪，不支持多段拼接' },
    },
  },
  {
    feature: '调色（亮度/对比/饱和/曝光）',
    cells: {
      kadr: { level: 'yes', note: '内置可动画滤镜：brightness/contrast/saturation/exposure/sepia 等' },
      cabbage: { level: 'partial', note: '需通过 VideoConfigurationProtocol 自行接入 CIFilter' },
      videolab: { level: 'partial', note: '需自定义 Operation（Metal shader），内置 LUT 滤镜' },
      vek: { level: 'yes', note: '内置亮度/对比度/饱和度三项调节' },
    },
  },
  {
    feature: '滤镜 / LUT / 自定义特效',
    cells: {
      kadr: { level: 'yes', note: '滤镜目录 + LUT + KadrVideoCompositor 自定义逐帧合成，滤镜可用关键帧动画驱动' },
      cabbage: { level: 'partial', note: '扩展协议完备但需全部自写；通常搭配 MetalPetal 补齐' },
      videolab: { level: 'yes', note: 'BasicOperation 可写自定义 Metal 特效，自带 LUT / 变焦模糊' },
      vek: { level: 'no', note: '无滤镜目录，仅三项基础调节' },
    },
  },
  {
    feature: '转场',
    cells: {
      kadr: { level: 'yes', note: 'Transition.fade/dissolve/slide 等一等公民 DSL 元素' },
      cabbage: { level: 'yes', note: 'TrackItem.videoTransition / audioTransition，可自定义' },
      videolab: { level: 'yes', note: '通过 Transform + 透明度动画手动构造，官方 demo 提供示例' },
      vek: { level: 'no', note: '不支持' },
    },
  },
  {
    feature: 'BGM / 音频混合',
    cells: {
      kadr: { level: 'yes', note: '时间锚定音轨、ducking、crossfade；kadr-audio 提供 LUFS 响度测量与配音录制' },
      cabbage: { level: 'yes', note: 'audioChannel 独立通道 + AudioConfigurationProtocol 可实时处理原始音频' },
      videolab: { level: 'yes', note: '音高设置 + 音量渐变（VolumeRamp）' },
      vek: { level: 'partial', note: '仅一条录制音轨与原声混合，无多音轨/闪避' },
    },
  },
  {
    feature: '变速',
    cells: {
      kadr: { level: 'yes', note: '0.25x–4x 保调变速（spectral/timeDomain/varispeed），支持曲线变速' },
      cabbage: { level: 'partial', note: '时间映射需自行处理，文档未提供现成 API' },
      videolab: { level: 'no', note: 'README 的 TODO 项，从未实现' },
      vek: { level: 'yes', note: '支持播放速度调节' },
    },
  },
  {
    feature: '画幅 / 画布调整',
    cells: {
      kadr: { level: 'yes', note: 'preset(.reelsAndShorts / .cinema) + crop + renderSize 自由指定' },
      cabbage: { level: 'yes', note: 'renderSize + baseContentMode（aspectFit/Fill）' },
      videolab: { level: 'yes', note: 'RenderComposition.renderSize + 每层 Transform' },
      vek: { level: 'yes', note: '裁剪预设 + 画布缩放/平移 + 旋转/镜像' },
    },
  },
  {
    feature: '字幕',
    cells: {
      kadr: { level: 'yes', note: 'kadr-captions 解析 SRT/VTT/iTT/ASS/SSA，桥接 TextOverlay 烧录动画字幕' },
      cabbage: { level: 'partial', note: '可用自定义 Resource / CALayer 实现，无现成方案' },
      videolab: { level: 'partial', note: 'CALayer 矢量动画支持复杂文字动画，需自搭建' },
      vek: { level: 'yes', note: '可选转写生成 + 可编辑字幕覆盖层' },
    },
  },
  {
    feature: '贴纸 / 图片覆盖',
    cells: {
      kadr: { level: 'yes', note: 'StickerOverlay / ImageOverlay，位置尺寸可动画；kadr-photos 桥接相册素材' },
      cabbage: { level: 'partial', note: 'ImageResource / PHAssetImageResource 可作为贴纸层' },
      videolab: { level: 'partial', note: '图片可作为 RenderLayer 叠加' },
      vek: { level: 'no', note: '仅导出时图片水印，无交互式贴纸' },
    },
  },
  {
    feature: '关键帧动画',
    cells: {
      kadr: { level: 'yes', note: 'Animation<T> 关键帧为片段相对时间，预览与导出一致' },
      cabbage: { level: 'partial', note: 'KeyframeVideoConfiguration 提供基础能力' },
      videolab: { level: 'yes', note: 'Animatable 协议 + KeyframeAnimation，支持 timingFunction' },
      vek: { level: 'no', note: '不支持' },
    },
  },
  {
    feature: '画中画 / 多轨叠加',
    cells: {
      kadr: { level: 'yes', note: '命名多轨车道 + .at(time:) 锚定 + Track 并行块' },
      cabbage: { level: 'partial', note: '多 TrackItem 时间区重叠即可叠加，需自管层级' },
      videolab: { level: 'yes', note: 'AE 式图层 + RenderLayerGroup 预合成' },
      vek: { level: 'no', note: '不支持' },
    },
  },
  {
    feature: '编辑状态持久化（草稿）',
    cells: {
      kadr: { level: 'yes', note: 'kadr-persistence：内容寻址存储 + 完整性守卫，拒绝静默丢字段' },
      cabbage: { level: 'no', note: '需自行序列化 Timeline 配置' },
      videolab: { level: 'no', note: '需自行实现' },
      vek: { level: 'yes', note: '可序列化编辑状态为核心卖点' },
    },
  },
  {
    feature: '现成 UI 组件',
    cells: {
      kadr: { level: 'yes', note: 'kadr-ui 独立包：多车道 TimelineView / VideoPreview / 转场选择器 / 分割器 / 关键帧编辑器' },
      cabbage: { level: 'no', note: '纯逻辑框架，UI 全部自建（官方仅有 VideoCat demo）' },
      videolab: { level: 'no', note: '纯逻辑框架' },
      vek: { level: 'yes', note: '完整 SwiftUI 编辑器开箱即用，但可定制性受限' },
    },
  },
]

// ── 评估维度打分（分析性判断，1–5 分）────────────────────────
export interface ScoreSet {
  id: string
  name: string
  scores: Record<string, number>
}

export const DIMENSIONS = [
  { key: 'arch', label: '架构设计', hint: '抽象是否合理、数据逻辑是否清晰、UI 与逻辑是否分离' },
  { key: 'ext', label: '扩展性', hint: '自定义资源/滤镜/转场/合成器的接入成本' },
  { key: 'maint', label: '维护活跃度', hint: '近一年提交频率、版本节奏、issue 响应' },
  { key: 'feature', label: '功能完备度', hint: '对照目标功能清单的开箱覆盖率' },
  { key: 'maturity', label: '成熟度 / 社区', hint: 'star 规模、生产案例、文档与踩坑资料' },
  { key: 'swift', label: '现代 Swift', hint: 'Swift 6 严格并发、async/await、SwiftUI 亲和度' },
  { key: 'agent', label: 'Agent 亲和性', hint: 'DSL 可序列化/可程序化生成，能否脱离 UI 被 CLI/MCP 驱动' },
  { key: 'solo', label: '小团队适配', hint: '1-2 人团队的学习成本、自养负担、接入速度' },
] as const

export const SCORES: ScoreSet[] = [
  { id: 'kadr', name: 'Kadr', scores: { arch: 5, ext: 4.5, maint: 5, feature: 5, maturity: 2, swift: 5, agent: 5, solo: 4.5 } },
  { id: 'cabbage', name: 'Cabbage', scores: { arch: 4, ext: 4, maint: 1.5, feature: 3, maturity: 3.5, swift: 2.5, agent: 3.5, solo: 2 } },
  { id: 'videolab', name: 'VideoLab', scores: { arch: 4.5, ext: 4.5, maint: 1, feature: 4, maturity: 3, swift: 3, agent: 3, solo: 1.5 } },
  { id: 'vek', name: 'VideoEditorKit', scores: { arch: 3.5, ext: 3, maint: 4, feature: 2.5, maturity: 1.5, swift: 5, agent: 3, solo: 3.5 } },
]

// ── 淘汰名单 ─────────────────────────────────────────────────
export const GRAVEYARD = [
  { name: 'PixelSDK', reason: '官方宣布 2025-02-03 停服；且导出需商业 API key（无 key 带水印），本就不满足"纯开源"前提', url: 'https://github.com/GottaYotta/PixelSDK' },
  { name: 'BBMetalImage', reason: '2022-10 后停更，80+ 滤镜资产尚可但无人维护，不如 MetalPetal/Raster 一脉', url: 'https://github.com/Silence-GitHub/BBMetalImage' },
  { name: 'SCRecorder', reason: 'Objective-C 时代产物，2021 年后停更，分段拍摄需求由 NextLevel 接替', url: 'https://github.com/rFlex/SCRecorder' },
  { name: 'MetalVideoProcess', reason: '2020 年停更的 GPUImage3 衍生实验项目，仅具考古价值', url: 'https://github.com/metal-by-example/MetalVideoProcess' },
  { name: 'FFmpegKit', reason: '2025-01 官方退役；且其非 AVFoundation 技术路线，与本项目前提不符', url: 'https://github.com/arthenica/ffmpeg-kit' },
  { name: 'YiVideoEditor 等玩具级库', reason: '2021 年前后停更，只覆盖旋转/水印等零散功能，无时间线抽象', url: 'https://github.com/topics/video-editing?l=swift' },
]

// ── 生态时间线（维护活跃度图表用）─────────────────────────────
export const TODAY = '2026-09-28'
