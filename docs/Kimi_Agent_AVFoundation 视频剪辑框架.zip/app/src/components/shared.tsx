import type { ReactNode } from 'react'
import type { Coverage, MaintenanceStatus } from '@/data/report'

/** 章节标记：等宽大写编号 + 标题 */
export function SectionMarker({ no, zh, en }: { no: string; zh: string; en: string }) {
  return (
    <div className="reveal flex items-baseline gap-4 border-t border-[color:var(--line-strong)] pt-4">
      <span className="mono text-[11px] tracking-[0.18em] text-[color:var(--accent)]">{no}</span>
      <h2 className="text-[28px] md:text-[40px] font-black leading-none tracking-tight">{zh}</h2>
      <span className="mono hidden md:inline text-[11px] uppercase tracking-[0.22em] text-[color:var(--ink-faint)]">{en}</span>
    </div>
  )
}

/** 维护状态徽标 */
const STATUS_META: Record<MaintenanceStatus, { zh: string; cls: string }> = {
  active: { zh: '活跃维护', cls: 'bg-[color:var(--accent)] text-white' },
  slow: { zh: '低频维护', cls: 'bg-[color:var(--ink)] text-[color:var(--paper)]' },
  dormant: { zh: '休眠', cls: 'bg-[#6f7b74] text-white' },
  dead: { zh: '停止维护', cls: 'bg-transparent text-[color:var(--ink-soft)] border border-[color:var(--line)]' },
  sunset: { zh: '官方停服', cls: 'bg-[#b3261e] text-white' },
}

export function StatusBadge({ status }: { status: MaintenanceStatus }) {
  const m = STATUS_META[status]
  return <span className={`mono inline-block whitespace-nowrap rounded-[3px] px-1.5 py-0.5 text-[10px] tracking-wide ${m.cls}`}>{m.zh}</span>
}

/** 功能覆盖单元格 */
export function CoverageMark({ level }: { level: Coverage }) {
  if (level === 'yes')
    return (
      <span className="inline-flex h-[18px] w-[18px] items-center justify-center rounded-full bg-[color:var(--accent)]">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1.5 5.2 4 7.5 8.5 2.5" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </span>
    )
  if (level === 'partial')
    return <span className="inline-flex h-[18px] w-[18px] items-center justify-center rounded-full border-[1.5px] border-[color:var(--accent)]"><span className="h-[6px] w-[6px] rounded-full bg-[color:var(--accent)] opacity-60" /></span>
  return <span className="mono text-[13px] text-[color:var(--ink-faint)]">—</span>
}

/** 段落包装 */
export function Para({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <p className={`reveal text-[15px] leading-[1.95] text-[color:var(--ink-soft)] ${className}`}>{children}</p>
}
