import { useReveal } from '@/hooks/useReveal'
import Nav from '@/sections/Nav'
import Hero from '@/sections/Hero'
import Verdict from '@/sections/Verdict'
import Landscape from '@/sections/Landscape'
import DeepDive from '@/sections/DeepDive'
import AgentLens from '@/sections/AgentLens'
import FeatureMatrix from '@/sections/FeatureMatrix'
import MaintenanceChart from '@/sections/MaintenanceChart'
import FitCalculator from '@/sections/FitCalculator'
import Recommendation from '@/sections/Recommendation'
import Graveyard from '@/sections/Graveyard'
import Footer from '@/sections/Footer'

export default function Home() {
  useReveal()
  return (
    <div className="min-h-screen">
      <Nav />
      <main>
        <Hero />
        <Verdict />
        <Landscape />
        <DeepDive />
        <AgentLens />
        <FeatureMatrix />
        <MaintenanceChart />
        <FitCalculator />
        <Recommendation />
        <Graveyard />
      </main>
      <Footer />
    </div>
  )
}
