import { useState } from 'react'
import { FEATURE_MATRIX } from '@/data/report'
import { CoverageMark, Para, SectionMarker } from '@/components/shared'

const COLS = [
  { id: 'kadr', name: 'Kadr' },
  { id: 'cabbage', name: 'Cabbage' },
  { id: 'videolab', name: 'VideoLab' },
  { id: 'vek', name: 'VideoEditorKit' },
] as const

export default function FeatureMatrix() {
  const [tip, setTip] = useState<{ r: number; c: number } | null>(null)

  return (
    <section id="matrix" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="04" zh="功能覆盖矩阵" en="Feature Matrix" />
      <Para className="mt-8 max-w-[820px]">
        以目标功能清单为行、四个核心候选为列。<span className="inline-flex translate-y-[3px]"><CoverageMark level="yes" /></span> 开箱即用、
        <span className="inline-flex translate-y-[3px] mx-1"><CoverageMark level="partial" /></span> 有扩展点但需自建、
        <span className="mono text-[13px] text-[color:var(--ink-faint)]">—</span> 不支持。<strong className="text-[color:var(--ink)]">悬停任意单元格查看实现方式备注</strong>。
      </Para>

      <div className="reveal mt-8 overflow-x-auto border border-[color:var(--line-strong)]">
        <table className="grid-table min-w-[860px]">
          <thead>
            <tr className="bg-[color:var(--surface)]">
              <th className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">功能</th>
              {COLS.map((c) => (
                <th key={c.id} className={`mono px-3 py-2.5 text-center text-[11px] font-bold tracking-[0.1em] ${c.id === 'kadr' ? 'text-[color:var(--accent)]' : 'text-[color:var(--ink)]'}`}>{c.name}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {FEATURE_MATRIX.map((row, ri) => (
              <tr key={row.feature} className="transition-colors hover:bg-[color:var(--surface)]">
                <td className="px-3 py-3 text-[13px] font-semibold">{row.feature}</td>
                {COLS.map((c, ci) => {
                  const cell = row.cells[c.id]
                  const open = tip?.r === ri && tip?.c === ci
                  return (
                    <td
                      key={c.id}
                      className="relative cursor-help px-3 py-3 text-center"
                      onMouseEnter={() => setTip({ r: ri, c: ci })}
                      onMouseLeave={() => setTip(null)}
                      onClick={() => setTip(open ? null : { r: ri, c: ci })}
                    >
                      <CoverageMark level={cell.level} />
                      {open && (
                        <div className="absolute left-1/2 top-full z-30 w-[240px] -translate-x-1/2 border border-[color:var(--line-strong)] bg-[#161616] p-3 text-left text-[11.5px] leading-relaxed text-[#e8e6e3] shadow-[8px_8px_0_rgba(35,31,32,0.15)]">
                          <div className="mono mb-1 text-[9.5px] uppercase tracking-[0.18em] text-[#7da7ff]">{c.name} · {row.feature}</div>
                          {cell.note}
                        </div>
                      )}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Para className="mt-6 max-w-[820px]">
        矩阵的结论一目了然：<strong className="text-[color:var(--ink)]">Kadr 是唯一在 13 个维度上全部"开箱即用"的框架</strong>——
        尤其在变速（保调 + 曲线）、字幕（五种格式解析到动画烧录）、工程持久化这三个剪辑 App 的高门槛功能上，
        其余候选均存在明显缺口。Cabbage 与 VideoLab 的 "partial" 集中于同一原因：它们提供的是正确、干净的扩展协议，
        但协议背后的实现（滤镜、字幕渲染、贴纸交互）需要你自己填——这正是"基于它们开发"的真实成本所在。
      </Para>
    </section>
  )
}
