import { useState } from 'react'
import { Para, SectionMarker } from '@/components/shared'

interface Profile {
  id: string
  name: string
  meta: string
  arch: { title: string; body: string }[]
  strengths: string[]
  risks: string[]
  code: string
  codeNote: string
}

const PROFILES: Profile[] = [
  {
    id: 'kadr',
    name: 'Kadr',
    meta: 'SteliyanH/kadr · Apache-2.0 · v1.1（2026-09）· iOS 17+ / macOS 14+ / tvOS / visionOS · Swift 6',
    arch: [
      {
        title: '双层架构：DSL 外壳 + AVFoundation 引擎',
        body: '公开层是不可变值类型构成的 result-builder DSL（Video / VideoClip / Transition / AudioTrack / Filter），引擎层是 internal 的 CompositionBuilder、FilterProcessor、KadrVideoCompositor（自定义 AVVideoCompositing）、OverlayRenderer、ExportEngine。DSL 冻结于 v1.0 并承诺 semver：1.x 内不删不改不改义，引擎可随意重构。这是四个候选里唯一把"API 稳定性"写成契约的。',
      },
      {
        title: '全家桶分包：UI、持久化、字幕、音频、相册各自独立',
        body: 'kadr-ui（SwiftUI 时间线/预览/转场选择器/关键帧编辑器）、kadr-persistence（工程文件存取 + 完整性守卫）、kadr-audio（LUFS 响度、配音录制）、kadr-captions（SRT/VTT/iTT/ASS/SSA）、kadr-photos（PHAsset 桥接）五个伴随包全部只依赖 kadr 的公开 API。另有一个完全基于公开 API 构建的参考编辑器 Kadr Studio——作者称正是用"外部消费者"视角发现了 7 个内部测试看不见的 API 空洞。',
      },
      {
        title: '数据逻辑：声明即时间线，天然 Agent 可读',
        body: '剪辑状态就是一棵不可变的 DSL 树：片段裁剪是 trimmed(to:) 闭区间，转场是时间线里的一等元素，变速是 .flat 与 .curved 的编译期互斥枚举，音频 ducking/crossfade 按声明顺序语义化。关键帧以片段相对时间定义，预览（makePlayerItem）与导出（export）共用同一套动画驱动。这不仅是 UI 友好的设计，更是让 LLM 能"写出合法剪辑程序"的关键——Agent 生成的是意图，不是命令序列。',
      },
    ],
    strengths: [
      '唯一同时满足：活跃维护 + Swift 6 严格并发 + UI/逻辑分离 + 功能近全覆盖',
      'DSL 可序列化（kadr-persistence），headless 导出（exporter.run()），Agent/CLI/MCP 化路径最短',
      '变速 0.25x–4x 保调（spectral/timeDomain/varispeed 三算法）且支持曲线变速，竞品全无',
      '字幕链路完整：从 SRT/ASS 解析到动画烧录一体打通',
      'Apache-2.0 附带明确专利授权条款，对视频编解码场景比 MIT 更稳妥',
      'iOS / macOS / tvOS / visionOS 全平台，契合"Apple 平台通用"目标',
    ],
    risks: [
      '单作者项目，2026-04 才创建，56 star，无生产环境大规模验证',
      'iOS 17 起步意味着放弃老设备；UIKit 项目接入需包一层 SwiftUI',
      '自定义 Metal shader 能力目前依赖 CIFilter/compositor 桥接，不如 VideoLab 直接',
      '缓解措施：Apache-2.0 允许自由 fork；建议 fork 一份内部镜像并跟进其 semver 节奏；对 1-2 人团队，"不自养依赖"的价值大于"完全掌控"',
    ],
    code: `let url = try await Video {
    VideoClip(url: introURL).trimmed(to: 0...3)
    Transition.dissolve(duration: 0.5)
    VideoClip(url: actionURL).trimmed(to: 0...4)
        .speed(0.5)                          // 半速慢放，保调
        .filter(.brightness(0.05), .contrast(1.1), .saturation(1.2))
}
.overlay(
    TextOverlay("CHAPTER ONE", style: TextStyle(fontSize: 80, weight: .bold))
        .visible(during: 0.0...2.0)
        .animation(.fadeIn(duration: 1.0))
)
.audio {
    AudioTrack(url: musicURL).volume(0.6).ducking(0.2)  // BGM 闪避人声
}
.preset(.reelsAndShorts)                   // 9:16 画幅预设
.export(to: outputURL)`,
    codeNote: '一段 DSL 同时覆盖：多段裁剪、转场、变速、调色、字幕动画、BGM 闪避、画幅预设、导出。',
  },
  {
    id: 'cabbage',
    name: 'Cabbage',
    meta: 'VideoFlint/Cabbage · MIT · 1,578★ · 最后提交 2023-11 · iOS 9+ · Swift（4 时代代码风格）',
    arch: [
      {
        title: '四层概念：Resource → TrackItem → Timeline → CompositionGenerator',
        body: 'Resource 抽象数据源（视频/图片/音频，可继承扩展出 GIF 等自定义源），TrackItem 挂视频配置（transform/透明度/自定义滤镜链）与音频配置（音量/自定义处理节点），Timeline 是带 videoChannel/audioChannel 双通道的时间轴容器，CompositionGenerator 负责把 Timeline 翻译成 AVPlayerItem / AVAssetExportSession / AVAssetImageGenerator 三件套。概念少而正交，学习曲线平缓。',
      },
      {
        title: '扩展协议设计干净',
        body: 'VideoConfigurationProtocol 接自定义图像滤镜、AudioConfigurationProtocol 接自定义音频处理（内置 VolumeAudioConfiguration）、Resource 子类化接自定义数据源、videoTransition/audioTransition 接自定义转场。作者在 Wiki 里有一篇高质量的《iOS 视频编辑核心架构》长文，把 AVFoundation 原生 API 的繁琐之处（8 步流程、轨道时间信息易被变速/转场破坏）分析得非常透，本身就是优秀的架构教材。',
      },
    ],
    strengths: [
      '1.5k star + 多年生产使用，设计共识充分',
      '概念模型简单正交，二次开发心智负担低',
      'MIT + iOS 9 起步，兼容性极宽',
      '中文文档与架构文章完善，国内团队友好',
    ],
    risks: [
      '2023-11 后零提交，47 个 open issue 无人处理，实质进入社区托管状态',
      'Swift 4 时代代码，无 async/await 与严格并发，接入 Swift 6 工程需自行改造',
      '无内置滤镜/字幕/贴纸实现，变速需自处理时间映射——大量功能要搭配 MetalPetal/Raster 或自研补齐',
      '纯逻辑无 UI，编辑界面从零搭建',
    ],
    code: `// 1. 创建资源
let resource = AVAssetTrackResource(asset: asset)
// 2. TrackItem 挂载配置
let trackItem = TrackItem(resource: resource)
trackItem.configuration.videoConfiguration.baseContentMode = .aspectFill
// 3. 放入时间线
let timeline = Timeline()
timeline.videoChannel = [trackItem]
timeline.audioChannel = [trackItem]
// 4. 生成 AVFoundation 三件套
let generator = CompositionGenerator(timeline: timeline)
generator.renderSize = CGSize(width: 1920, height: 1080)
let playerItem = generator.buildPlayerItem()
let exportSession = generator.buildExportSession(
    presetName: AVAssetExportPresetMediumQuality)`,
    codeNote: '四步完成合成：资源 → 配置 → 时间线 → 生成器。扩展点全部走协议。',
  },
  {
    id: 'videolab',
    name: 'VideoLab',
    meta: 'ruanjx/VideoLab · MIT · 921★ · 最后提交 2022-10 · iOS 11+ · Swift · AVFoundation + Metal',
    arch: [
      {
        title: 'AE 式图层模型：RenderLayer / RenderComposition / VideoLab',
        body: '直接把 After Effects 的合成思想搬进 AVFoundation：每个视频/图片/音频/特效都是 RenderLayer，RenderComposition 是画布（帧率、尺寸、CALayer 矢量动画），VideoLab 负责产出播放器与导出会话。自定义 AVVideoCompositing 合成器用 Metal 逐帧渲染，性能上限高于纯 instruction 方案。',
      },
      {
        title: '动画系统是唯一真完整的',
        body: 'Animatable 协议 + KeyframeAnimation（keyPath/values/keyTimes/timingFunctions）可以对 Transform、透明度乃至自定义特效参数（如变焦模糊的 blurSize）做关键帧动画；RenderLayerGroup 实现 AE 式预合成。这套设计直接启发了后来者对"剪辑引擎动画系统该怎么写"的认知。',
      },
    ],
    strengths: [
      '四个候选中特效天花板最高：Metal 自定义 Operation 直接写 shader',
      '关键帧动画 + 预合成 + CALayer 文字动画，设计完成度极高',
      '附有质量很高的《框架设计与实现》中文长文，把 AVVideoComposition/Compositor 机制讲透了',
    ],
    risks: [
      '2022-10 停更至今 4 年，变速功能始终是 TODO，无人认领',
      'CocoaPods 分发为主，无 SPM 一等支持',
      '正确姿势：fork 或阅读其设计文档作为自研蓝本，不建议原样依赖',
    ],
    code: `// 关键帧动画：2s→4s→6s 透明度 1.0→0.2→1.0
let animation = KeyframeAnimation(
    keyPath: "blendOpacity",
    values: [1.0, 0.2, 1.0],
    keyTimes: keyTimes,
    timingFunctions: [.linear, .linear])
renderLayer1.animations = [animation]

// 自定义 Metal 特效 + 参数动画
var zoomblur = ZoomBlur()
zoomblur.animations = [KeyframeAnimation(
    keyPath: "blurSize", values: [0.0, 3.0],
    keyTimes: keyTimes, timingFunctions: [.quarticEaseOut])]
layerGroup.operations = [zoomblur]   // 预合成组整组加特效`,
    codeNote: 'AE 思想：图层 + 关键帧 + 预合成 + shader 级自定义特效。',
  },
  {
    id: 'vek',
    name: 'VideoEditorKit',
    meta: 'didisouzacosta/VideoEditorKit · MIT · 19★ · 创建于 2026-04 · iOS 18.6+ / Swift 6 · SwiftUI',
    arch: [
      {
        title: '思路相反的一极：UI 先行，开箱即用',
        body: '直接提供一个可 present 的完整 SwiftUI 编辑器（裁剪、速度、裁剪预设、画布缩放平移、旋转镜像、亮度对比度饱和度、字幕覆盖层、导出质量选择），编辑状态可序列化，宿主通过配置项控制行为。技术栈极新：Swift 6 + Observation + PhotosUI + Swift Testing。',
      },
    ],
    strengths: [
      '真正开箱即用，从零到有编辑界面只需几十行代码',
      '可序列化编辑状态是刚需功能的现成实现',
      'Swift 6 / Observation 现代栈，代码可读性好',
    ],
    risks: [
      'iOS 18.6+ 起步，等于只服务 2026 年后的系统版本，安装基数极小',
      '仅支持单视频编辑：无多段拼接、无转场、无贴纸、无多音轨——与目标功能清单差距大',
      '单作者、19 star，方向是"嵌入式轻编辑器"而非"通用剪辑引擎"',
      '定位建议：功能需求恰好匹配时可考虑；本项目场景下仅作观察',
    ],
    code: `// SwiftUI 中直接嵌入完整编辑器
import VideoEditorKit

struct ContentView: View {
    @State private var editingURL: URL?

    var body: some View {
        VideoEditorView(url: editingURL) { result in
            // 编辑状态可序列化保存为草稿
            // 导出可选 original / low / medium / high
        }
    }
}`,
    codeNote: 'UI 与状态一体交付，适合"嵌入一个编辑器"而非"构建一个剪辑产品"。',
  },
]

export default function DeepDive() {
  const [active, setActive] = useState('kadr')
  const p = PROFILES.find((x) => x.id === active)!

  return (
    <section id="deepdive" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="03" zh="核心候选深度评析" en="Deep Dive" />
      <Para className="mt-8 max-w-[820px]">
        四个进入决赛圈的框架，代表了四种不同的设计哲学：Kadr 的"声明式 DSL"、Cabbage 的"最小正交抽象"、
        VideoLab 的"AE 图层模拟"、VideoEditorKit 的"UI 先行"。点击切换查看。
      </Para>

      <div className="reveal mt-8 flex flex-wrap gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)]">
        {PROFILES.map((x) => (
          <button
            key={x.id}
            onClick={() => setActive(x.id)}
            className={`mono flex-1 whitespace-nowrap px-4 py-3 text-[12px] tracking-[0.14em] transition-colors ${
              active === x.id ? 'bg-[color:var(--ink)] text-[color:var(--paper)]' : 'bg-[color:var(--paper)] text-[color:var(--ink-soft)] hover:text-[color:var(--accent)]'
            }`}
          >
            {x.name}
          </button>
        ))}
      </div>

      <div className="border border-t-0 border-[color:var(--line-strong)] p-6 md:p-10" key={p.id}>
        <div className="mono text-[11px] tracking-[0.1em] text-[color:var(--ink-faint)]">{p.meta}</div>
        <div className="mt-8 grid gap-10 lg:grid-cols-2">
          <div className="space-y-8">
            {p.arch.map((a) => (
              <div key={a.title}>
                <h4 className="flex items-baseline gap-2 text-[17px] font-bold">
                  <span className="mono text-[10px] text-[color:var(--accent)]">▸</span>{a.title}
                </h4>
                <p className="mt-2 text-[13.5px] leading-[1.95] text-[color:var(--ink-soft)]">{a.body}</p>
              </div>
            ))}
          </div>
          <div>
            <div className="codeblock p-5">
              <pre className="whitespace-pre">{p.code}</pre>
            </div>
            <p className="mono mt-2 text-[10.5px] leading-relaxed text-[color:var(--ink-faint)]">{p.codeNote}</p>
          </div>
        </div>
        <div className="mt-10 grid gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)] md:grid-cols-2">
          <div className="bg-[color:var(--paper)] p-5">
            <div className="mono text-[10px] uppercase tracking-[0.22em] text-[color:var(--accent)]">优势 Strengths</div>
            <ul className="mt-3 space-y-2">
              {p.strengths.map((s) => (
                <li key={s} className="flex gap-2 text-[13px] leading-[1.8] text-[color:var(--ink-soft)]">
                  <span className="mt-[7px] h-[5px] w-[5px] shrink-0 rounded-full bg-[color:var(--accent)]" />{s}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-[color:var(--paper)] p-5">
            <div className="mono text-[10px] uppercase tracking-[0.22em] text-[#b3261e]">风险 Risks</div>
            <ul className="mt-3 space-y-2">
              {p.risks.map((s) => (
                <li key={s} className="flex gap-2 text-[13px] leading-[1.8] text-[color:var(--ink-soft)]">
                  <span className="mt-[7px] h-[5px] w-[5px] shrink-0 rounded-full bg-[#b3261e]" />{s}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
