import { useMemo, useState } from 'react'
import { DIMENSIONS, SCORES } from '@/data/report'
import { Para, SectionMarker } from '@/components/shared'

export default function FitCalculator() {
  const [weights, setWeights] = useState<Record<string, number>>({
    arch: 5, ext: 4, maint: 5, feature: 4, maturity: 2, swift: 3, agent: 5, solo: 5,
  })

  const results = useMemo(() => {
    const totalW = Object.values(weights).reduce((a, b) => a + b, 0) || 1
    return SCORES.map((s) => {
      const weighted = DIMENSIONS.reduce((acc, d) => acc + s.scores[d.key] * weights[d.key], 0) / totalW
      return { ...s, weighted }
    }).sort((a, b) => b.weighted - a.weighted)
  }, [weights])

  const max = 5

  return (
    <section id="fit" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="06" zh="需求匹配计算器" en="Fit Calculator" />
      <Para className="mt-8 max-w-[820px]">
        八个评估维度各按 1–5 打分，分数为本报告基于代码阅读与文档分析的判断。
        <strong className="text-[color:var(--ink)]">已按你的新背景预置权重</strong>：Agent 亲和性与小团队适配均设为最高档（5），
        成熟度维持低位（2）——因为 side project 阶段"没人替你维护"比"没人用过"更危险。
        <strong className="text-[color:var(--ink)]">拖动滑块调整优先级</strong>，右侧加权得分实时重排。
      </Para>

      <div className="reveal mt-8 grid gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)] lg:grid-cols-2">
        <div className="bg-[color:var(--paper)] p-6 md:p-8">
          <div className="mono text-[10px] uppercase tracking-[0.22em] text-[color:var(--ink-faint)]">权重 Weights</div>
          <div className="mt-5 space-y-5">
            {DIMENSIONS.map((d) => (
              <div key={d.key}>
                <div className="flex items-baseline justify-between">
                  <label className="text-[14px] font-bold">{d.label}</label>
                  <span className="mono text-[12px] font-bold text-[color:var(--accent)]">{weights[d.key]}</span>
                </div>
                <input
                  type="range" min={0} max={5} step={1}
                  value={weights[d.key]}
                  onChange={(e) => setWeights({ ...weights, [d.key]: Number(e.target.value) })}
                  className="mt-2 w-full accent-[#1400ff]"
                />
                <div className="mt-0.5 text-[11px] text-[color:var(--ink-faint)]">{d.hint}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-[color:var(--paper)] p-6 md:p-8">
          <div className="mono text-[10px] uppercase tracking-[0.22em] text-[color:var(--ink-faint)]">加权得分 Weighted Score</div>
          <div className="mt-5 space-y-4">
            {results.map((r, i) => (
              <div key={r.id}>
                <div className="flex items-baseline justify-between">
                  <span className={`text-[14px] font-bold ${i === 0 ? 'text-[color:var(--accent)]' : ''}`}>
                    {i === 0 && <span className="mono mr-1 text-[10px]">▲</span>}{r.name}
                  </span>
                  <span className="mono text-[12px] font-medium">{r.weighted.toFixed(2)}</span>
                </div>
                <div className="mt-1.5 h-[10px] w-full border border-[color:var(--line)]">
                  <div
                    className={`h-full transition-all duration-500 ease-out ${i === 0 ? 'bg-[color:var(--accent)]' : 'bg-[rgba(35,31,32,0.35)]'}`}
                    style={{ width: `${(r.weighted / max) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <p className="mt-6 text-[11.5px] leading-[1.8] text-[color:var(--ink-faint)]">
            试一个实验：把"Agent 亲和性"和"小团队适配"都拉到 0，再把"成熟度"拉到 5——Cabbage 会短暂反超。
            但这正是 side project 的陷阱：成熟度的分数来自历史，而你要维护的是未来。
          </p>
        </div>
      </div>
    </section>
  )
}
