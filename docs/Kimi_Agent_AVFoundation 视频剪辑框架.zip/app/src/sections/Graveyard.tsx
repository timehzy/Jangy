import { GRAVEYARD } from '@/data/report'
import { Para, SectionMarker } from '@/components/shared'

export default function Graveyard() {
  return (
    <section id="graveyard" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="08" zh="淘汰名单" en="Excluded" />
      <Para className="mt-8 max-w-[820px]">
        以下项目在检索中出现频率较高，但经核实不满足"纯开源 + 持续维护"前提，记录在此以免重复评估。
      </Para>
      <div className="mt-8 grid gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)] md:grid-cols-2">
        {GRAVEYARD.map((g, i) => (
          <div key={g.name} className="reveal bg-[color:var(--paper)] p-5" style={{ transitionDelay: `${i * 60}ms` }}>
            <div className="flex items-baseline justify-between gap-3">
              <a href={g.url} target="_blank" rel="noreferrer" className="inline-link mono text-[13px] font-bold">{g.name}</a>
              <span className="mono shrink-0 text-[9.5px] uppercase tracking-[0.18em] text-[#b3261e]">EXCLUDED</span>
            </div>
            <p className="mt-2 text-[12.5px] leading-[1.85] text-[color:var(--ink-soft)]">{g.reason}</p>
          </div>
        ))}
      </div>

      <div className="reveal mt-12 border border-[color:var(--line-strong)] bg-[#161616] p-6 md:p-8">
        <div className="mono text-[10px] uppercase tracking-[0.22em] text-[#7da7ff]">METHODOLOGY · 调研方法与数据说明</div>
        <div className="mt-4 grid gap-6 text-[12.5px] leading-[1.9] text-[#b8b5b2] md:grid-cols-2">
          <p>
            调研范围限定为"基于 AVFoundation 的纯开源框架"，商业 SDK（Banuba、img.ly VE.SDK、美摄、BytePlus 等）
            按用户要求仅作背景参照、未纳入评估。候选发现渠道：GitHub topic 检索（avfoundation / video-editing /
            video-editor 等）、中文社区选型文章、awesome-ios 清单交叉验证。
          </p>
          <p>
            仓库指标（star / 最后提交 / License / 语言）为 2026-09-28 通过 GitHub API 实时查询；
            功能覆盖判断基于各仓库 README、Wiki 与官方文档原文。功能矩阵中的"部分支持"意味着框架提供了正确的扩展协议
            但无开箱实现；评估打分为分析性判断，已尽量标注依据，建议结合自身 POC 验证。
          </p>
        </div>
      </div>
    </section>
  )
}
