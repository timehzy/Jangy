import { Para, SectionMarker } from '@/components/shared'

const ROWS = [
  {
    id: 'kadr', name: 'Kadr', ok: true,
    points: [
      ['DSL 即代码', '时间线是一棵不可变值类型的 result-builder 树，LLM 可以直接"写出"一段合法剪辑程序'],
      ['可序列化', 'kadr-persistence 把 DSL 树持久化为工程文件（内容寻址 + 完整性守卫），天然是 Agent 的读写格式'],
      ['headless 导出', 'exporter.run() 返回 AsyncThrowingStream 进度，不依赖任何 UI 组件，可跑在 CLI / 服务端（Apple 平台）'],
      ['参考实现', 'Kadr Studio 是完全基于公开 API 的编辑器，证明了"同一引擎可被 UI 与程序双驱动"'],
    ],
    code: `// Agent 生成的剪辑指令（JSON）→ 反序列化为 Kadr DSL → 导出
let edit = try EditPlan(json: agentOutput)
let url = try await Video {
    for clip in edit.clips {
        VideoClip(url: clip.url).trimmed(to: clip.range)
        if let t = clip.transition { Transition(t) }
    }
}
.audio { AudioTrack(url: edit.bgm).ducking(edit.duck) }
.export(to: outputURL)`,
    note: 'DSL 的"声明式"本质是：UI 是 DSL 的一种渲染器，Agent 是另一种。',
  },
  {
    id: 'cabbage', name: 'Cabbage', ok: false,
    points: [
      ['命令式配置', 'TrackItem 需逐字段赋值（baseContentMode / transform / opacity），Agent 生成的是"胶水代码"而非"剪辑意图"'],
      ['无持久化层', 'Timeline 是内存对象，需自行设计序列化 schema，Agent 的草稿格式要自己造'],
      ['UI 耦合隐含', '虽然框架本身无 UI，但 Resource/TrackItem 的创建依赖 AVAsset 加载流程，CLI 化需自行封装'],
    ],
    code: `// Agent 需要理解并生成大量命令式配置
let trackItem = TrackItem(resource: resource)
trackItem.configuration.videoConfiguration.baseContentMode = .aspectFill
trackItem.configuration.videoConfiguration.configurations = [CustomFilter()]
// 时间映射、变速、转场的时间偏移都需 Agent 显式计算`,
    note: '可行，但 Agent 到执行的每一步都需要人工垫片。',
  },
  {
    id: 'videolab', name: 'VideoLab', ok: false,
    points: [
      ['图层模型重', 'AE 式 RenderLayer 对 UI 友好，但 Agent 需要理解图层坐标、锚点、预合成等视觉概念'],
      ['无序列化', 'RenderComposition 无持久化方案，草稿/Agent 指令需自建'],
      ['Metal 上下文', '自定义合成器依赖 GPU 上下文，headless 导出可行但代码路径与 UI 预览分叉'],
    ],
    code: `// Agent 需要操作 Transform / KeyframeAnimation / RenderLayerGroup
let transform = Transform(center: CGPoint(x: 0.25, y: 0.25), rotation: 0, scale: 0.5)
renderLayer1.transform = transform
// 时间线不是声明式数据，而是图层对象的命令式组装`,
    note: '特效天花板高，但 Agent 化成本也最高。',
  },
] as const

export default function AgentLens() {
  return (
    <section id="agent" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="03.5" zh="Agent / CLI / MCP 亲和性" en="Agent Readiness" />
      <Para className="mt-8 max-w-[820px]">
        这是本次选型最容易被忽略、但对"AI 剪辑 Agent"目标最致命的一个维度。
        剪辑框架的 API 风格决定了 Agent 是"生成一段意图"还是"模拟一堆点击"。
        同时，MCP 生态里已有 <a className="inline-link" href="https://mcpmarket.com/server/video-editor-4" target="_blank" rel="noreferrer">mcp-video</a>（Python/FFmpeg，26 个结构化工具）
        和 <a className="inline-link" href="https://blitzreels.com/agents" target="_blank" rel="noreferrer">BlitzReels</a>（云端 MCP/CLI/API）等参照——
        它们的共同点是<strong className="text-[color:var(--ink)]">把剪辑抽象为"结构化工具调用"而非"UI 操作回放"</strong>。
        一个 Apple 平台框架能否进入这个生态，取决于它的 DSL 能否被序列化、被 LLM 稳定生成、在无 UI 环境执行。
      </Para>

      <div className="mt-10 space-y-6">
        {ROWS.map((r) => (
          <article key={r.id} className="reveal border border-[color:var(--line-strong)]">
            <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-[color:var(--line-strong)] bg-[color:var(--surface)] px-5 py-3">
              <h3 className={`text-[18px] font-black ${r.ok ? 'text-[color:var(--accent)]' : ''}`}>{r.name}</h3>
              <span className={`mono rounded-[3px] px-1.5 py-0.5 text-[9.5px] tracking-[0.18em] ${r.ok ? 'bg-[color:var(--accent)] text-white' : 'bg-[color:var(--surface)] text-[color:var(--ink-soft)]'}`}>
                {r.ok ? 'AGENT-READY' : 'REQUIRES ADAPTER'}
              </span>
              <span className="mono text-[10.5px] text-[color:var(--ink-faint)]">{r.note}</span>
            </div>
            <div className="grid md:grid-cols-[1fr_1fr]">
              <ul className="divide-y divide-[color:var(--line)]">
                {r.points.map(([k, v]) => (
                  <li key={k} className="px-5 py-3">
                    <div className="text-[13px] font-bold">{k}</div>
                    <div className="mt-0.5 text-[12.5px] leading-[1.85] text-[color:var(--ink-soft)]">{v}</div>
                  </li>
                ))}
              </ul>
              <div className="border-t border-[color:var(--line)] md:border-l md:border-t-0">
                <div className="codeblock m-4 p-4">
                  <pre className="whitespace-pre-wrap">{r.code}</pre>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      <Para className="mt-8 max-w-[820px]">
        结论：Kadr 是四个候选中唯一把"可被程序生成"作为设计目标的——它的 DSL 冻结承诺（semver）意味着
        Agent 生成的代码不会在下个小版本失效；`EditPlan → DSL → Export` 的链路已经被 persistence 包打通。
        Cabbage 和 VideoLab 并非不能 CLI 化，而是需要你在框架之上再包一层"意图 → 命令"的翻译器，
        对 1-2 人团队来说这是额外且长期的维护负担。
      </Para>
    </section>
  )
}
