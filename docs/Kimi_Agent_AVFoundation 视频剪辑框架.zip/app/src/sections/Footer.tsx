export default function Footer() {
  return (
    <footer className="mt-10 border-t border-[color:var(--line-strong)]">
      <div className="mx-auto flex max-w-[1200px] flex-col gap-3 px-5 py-8 md:flex-row md:items-center md:justify-between">
        <div className="mono text-[10.5px] tracking-[0.16em] text-[color:var(--ink-faint)]">
          AVF/REPORT · iOS 开源视频剪辑框架调研 · 数据截至 2026-09-28
        </div>
        <div className="mono text-[10.5px] tracking-[0.16em] text-[color:var(--ink-faint)]">
          本报告仅供技术选型参考，不构成法律意见；License 合规请在商用前复核
        </div>
      </div>
    </footer>
  )
}
