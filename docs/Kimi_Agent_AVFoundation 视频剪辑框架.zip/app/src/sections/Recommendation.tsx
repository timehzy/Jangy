import { Para, SectionMarker } from '@/components/shared'

const PATHS = [
  {
    no: 'A',
    name: 'Kadr 全家桶直达（默认推荐）',
    fit: '适合：1-2 人 side project、需快速覆盖全功能、未来要 CLI/MCP 化、可接受 iOS 17+',
    stack: [
      ['剪辑引擎', 'kadr（DSL + 引擎，Apache-2.0，Agent 可直接生成）'],
      ['编辑 UI', 'kadr-ui（TimelineView / VideoPreview / TransitionPicker / ClipSplitter / KeyframeEditor）'],
      ['字幕', 'kadr-captions（SRT / VTT / iTT / ASS / SSA → 动画烧录）'],
      ['音频', 'kadr-audio（LUFS 响度、配音录制、ducking）'],
      ['草稿/Agent 指令', 'kadr-persistence（内容寻址 + 完整性守卫，天然是序列化格式）'],
      ['素材导入', 'kadr-photos 或 YPImagePicker'],
      ['拍摄（可选）', 'NextLevel'],
      ['CLI/MCP 化', '基于 kadr-persistence 的 EditPlan JSON → DSL 映射，参考 mcp-video 的 26 工具抽象'],
    ],
    note: '对 1-2 人团队，这是唯一"不自养任何依赖"的方案。Agent 化路径最短：LLM 生成 JSON EditPlan → 反序列化为 Kadr DSL → headless 导出。第一天就 fork 内部镜像，锁定 from: "1.0.0"。',
  },
  {
    no: 'B',
    name: 'Cabbage 内核 + MetalPetal/Raster 滤镜',
    fit: '适合：要求代码完全自主可控、团队有能力长期自养依赖、需兼容 iOS 9-16 老设备',
    stack: [
      ['剪辑内核', 'Cabbage（fork 后自维护，iOS 9+）'],
      ['滤镜/渲染', 'MetalPetal 1.26 兼容线，或 Raster 2.x（MTI* API 不变）'],
      ['转场', 'Cabbage videoTransition + MetalPetal MTTransitions'],
      ['裁剪 UI', 'PryntTrimmerView（UIKit）或自研 SwiftUI 组件'],
      ['字幕/贴纸', '基于 Cabbage ImageResource / CALayer 自建'],
      ['拍摄（可选）', 'NextLevel'],
      ['CLI/MCP 化', '需自建"意图 → TrackItem 配置"翻译层，工作量约等于半个框架'],
    ],
    note: '真实成本：你接手的是两个停更项目（Cabbage 2023-11、MetalPetal 2024-04）。对 1-2 人团队，47 个 open issue 和缺失的变速/字幕/贴纸实现，会吃掉本应用于产品差异化的时间。',
  },
  {
    no: 'C',
    name: '以 VideoLab 为蓝本自研引擎',
    fit: '适合：追求极致特效性能（Metal shader 级）、有专职音视频工程师、周期充裕',
    stack: [
      ['架构蓝本', 'VideoLab 的 RenderLayer / KeyframeAnimation / 预合成模型'],
      ['机制教材', 'Cabbage Wiki《iOS 视频编辑核心架构》+ VideoLab《框架设计与实现》'],
      ['合成器', '自定义 AVVideoCompositing + Metal（参考 VideoLab 实现）'],
      ['滤镜', 'Raster（HDR/广色域正确性是其重点）'],
      ['CLI/MCP 化', '自研引擎的最大优势：可以把 DSL 设计成 Agent-first 的声明式格式'],
    ],
    note: '成本最高但天花板也最高。对 side project，建议先用方案 A 验证产品，特效性能成为瓶颈时再演进到此方案——那时你已经有真实用户和收入，可以支撑自研。',
  },
] as const

const RISKS = [
  ['单作者依赖', 'Kadr / VideoEditorKit 均为单作者项目', 'fork 预案 + API 契约审查 + 关键路径封装隔离；Kadr 的 semver 冻结承诺降低升级风险', '中'],
  ['HDR / 广色域', '多数开源框架对 10-bit HDR 剪辑管线支持不完整；Raster 把 HDR 正确性列为重点但视频非其优先级', '立项即测 HDR 素材端到端（预览+导出）链路', '中'],
  ['编解码专利', 'H.264/HEVC 触及专利池', '优先选 Apache-2.0（含专利授权条款）的项目；商用前做合规确认', '低'],
  ['Swift 6 迁移', 'Cabbage / VideoLab 为严格并发前的代码', '若选方案 B，先做并发审计再接入', '中'],
  ['模拟器渲染', 'Metal 系滤镜在 Simulator 上部分不可用（如 MPS 滤镜）', '真机测试纳入 CI', '低'],
  ['Agent 指令漂移', 'LLM 生成的剪辑 JSON 可能超出 DSL 表达能力或包含非法时间区间', 'EditPlan schema 校验 + 非法指令的降级策略（如忽略/截断）', '中'],
  ['side project 时间', '1-2 人团队同时维护 App + Agent 接入层，易过载', '严格遵循方案 A 的"零自养"原则；UI 用 kadr-ui 原型，差异化功能后置', '中'],
] as const

export default function Recommendation() {
  return (
    <section id="recommendation" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="07" zh="选型建议" en="Recommendation" />
      <Para className="mt-8 max-w-[820px]">
        综合功能覆盖、架构质量与维护现实，给出三条可执行的落地路径。<strong className="text-[color:var(--ink)]">默认推荐 A</strong>：
        它用最小的前期成本覆盖你列出的全部功能，且"引擎/UI/字幕/音频/持久化"的分包结构恰好满足 UI 与逻辑分离的要求；
        B 与 C 是风险偏好不同下的退路。
      </Para>

      <div className="mt-10 space-y-6">
        {PATHS.map((p, i) => (
          <article key={p.no} className="reveal border border-[color:var(--line-strong)]" style={{ transitionDelay: `${i * 80}ms` }}>
            <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-[color:var(--line-strong)] bg-[color:var(--surface)] px-5 py-3">
              <span className={`mono text-[20px] font-bold ${p.no === 'A' ? 'text-[color:var(--accent)]' : 'text-[color:var(--ink)]'}`}>{p.no}</span>
              <h3 className="text-[18px] font-black">{p.name}</h3>
              {p.no === 'A' && <span className="mono rounded-[3px] bg-[color:var(--accent)] px-1.5 py-0.5 text-[9.5px] tracking-[0.18em] text-white">DEFAULT</span>}
              <span className="mono text-[10.5px] text-[color:var(--ink-faint)]">{p.fit}</span>
            </div>
            <div className="grid md:grid-cols-[1.2fr_1fr]">
              <table className="w-full">
                <tbody>
                  {p.stack.map(([k, v]) => (
                    <tr key={k} className="border-b border-[color:var(--line)] last:border-0">
                      <td className="mono whitespace-nowrap px-5 py-2.5 text-[11px] uppercase tracking-[0.12em] text-[color:var(--ink-faint)]">{k}</td>
                      <td className="px-5 py-2.5 text-[13px] leading-relaxed">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="border-t border-[color:var(--line)] p-5 text-[12.5px] leading-[1.9] text-[color:var(--ink-soft)] md:border-l md:border-t-0">
                {p.note}
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* 风险登记册 */}
      <h3 className="reveal mt-14 text-[22px] font-black">风险登记册 <span className="mono ml-2 text-[10px] uppercase tracking-[0.22em] text-[color:var(--ink-faint)]">Risk Register</span></h3>
      <div className="reveal mt-4 overflow-x-auto border border-[color:var(--line-strong)]">
        <table className="grid-table min-w-[820px]">
          <thead>
            <tr className="bg-[color:var(--surface)]">
              {['风险', '说明', '缓解措施', '等级'].map((h) => (
                <th key={h} className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RISKS.map(([name, desc, mitigation, level]) => (
              <tr key={name} className="hover:bg-[color:var(--surface)]">
                <td className="whitespace-nowrap px-3 py-3 text-[13px] font-bold">{name}</td>
                <td className="px-3 py-3 text-[12.5px] leading-relaxed text-[color:var(--ink-soft)]">{desc}</td>
                <td className="px-3 py-3 text-[12.5px] leading-relaxed text-[color:var(--ink-soft)]">{mitigation}</td>
                <td className="px-3 py-3">
                  <span className={`mono rounded-[3px] px-1.5 py-0.5 text-[10px] ${level === '中' ? 'bg-[color:var(--ink)] text-[color:var(--paper)]' : 'bg-[color:var(--surface)] text-[color:var(--ink-soft)]'}`}>{level}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
