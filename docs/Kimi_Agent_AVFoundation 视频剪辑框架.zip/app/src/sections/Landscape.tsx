import { useMemo, useState } from 'react'
import { REPOS, type Category, type Repo } from '@/data/report'
import { Para, SectionMarker, StatusBadge } from '@/components/shared'

const CAT_LABEL: Record<Category | 'all', string> = {
  all: '全部',
  core: '剪辑内核',
  render: '渲染/滤镜引擎',
  ui: 'UI 组件',
  capture: '拍摄',
  picker: '素材选择',
}

type SortKey = 'stars' | 'lastPush' | 'name'

function daysSince(iso: string) {
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000)
}

export default function Landscape() {
  const [cat, setCat] = useState<Category | 'all'>('all')
  const [sortKey, setSortKey] = useState<SortKey>('stars')
  const [asc, setAsc] = useState(false)

  const rows = useMemo(() => {
    const filtered = REPOS.filter((r) => cat === 'all' || r.category === cat)
    const dir = asc ? 1 : -1
    return [...filtered].sort((a, b) => {
      if (sortKey === 'stars') return (a.stars - b.stars) * dir
      if (sortKey === 'name') return a.name.localeCompare(b.name) * (asc ? 1 : -1)
      return (new Date(a.lastPush).getTime() - new Date(b.lastPush).getTime()) * dir
    })
  }, [cat, sortKey, asc])

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setAsc(!asc)
    else {
      setSortKey(k)
      setAsc(false)
    }
  }

  const Th = ({ k, children, className = '' }: { k: SortKey; children: string; className?: string }) => (
    <th
      onClick={() => toggleSort(k)}
      className={`mono cursor-pointer select-none px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] transition-colors hover:text-[color:var(--accent)] ${sortKey === k ? 'text-[color:var(--accent)]' : 'text-[color:var(--ink-faint)]'} ${className}`}
    >
      {children} {sortKey === k ? (asc ? '↑' : '↓') : ''}
    </th>
  )

  return (
    <section id="landscape" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="02" zh="生态全景" en="Landscape" />
      <Para className="mt-8 max-w-[820px]">
        一个完整的剪辑 App 技术栈至少包含五层：剪辑内核（时间线/合成）、渲染与滤镜引擎、编辑 UI、拍摄、素材选择。
        下表汇总了 12 个候选仓库的实时 GitHub 指标（2026-09-28 查询）——<strong className="text-[color:var(--ink)]">点击列头可排序，用分类标签过滤</strong>。
        注意"最后提交"一列：它几乎决定了每个候选的命运。
      </Para>

      <div className="reveal mt-8 flex flex-wrap gap-2">
        {(Object.keys(CAT_LABEL) as (Category | 'all')[]).map((k) => (
          <button
            key={k}
            onClick={() => setCat(k)}
            className={`mono border px-3 py-1.5 text-[11px] tracking-[0.12em] transition-colors ${
              cat === k
                ? 'border-[color:var(--accent)] bg-[color:var(--accent)] text-white'
                : 'border-[color:var(--line)] text-[color:var(--ink-soft)] hover:border-[color:var(--accent)] hover:text-[color:var(--accent)]'
            }`}
          >
            {CAT_LABEL[k]}
          </button>
        ))}
      </div>

      <div className="reveal mt-4 overflow-x-auto border border-[color:var(--line-strong)]">
        <table className="grid-table min-w-[960px]">
          <thead>
            <tr className="bg-[color:var(--surface)]">
              <Th k="name">仓库</Th>
              <th className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">定位</th>
              <Th k="stars">Stars</Th>
              <Th k="lastPush">最后提交</Th>
              <th className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">License</th>
              <th className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">平台</th>
              <th className="mono px-3 py-2.5 text-left text-[10.5px] font-medium uppercase tracking-[0.16em] text-[color:var(--ink-faint)]">状态</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r: Repo) => {
              const stale = daysSince(r.lastPush)
              return (
                <tr key={r.id} className="group transition-colors hover:bg-[color:var(--accent-soft)]">
                  <td className="px-3 py-3">
                    <a className="inline-link font-bold text-[14px]" href={r.url} target="_blank" rel="noreferrer">{r.name}</a>
                    <div className="mono mt-0.5 text-[10px] text-[color:var(--ink-faint)]">{r.owner}</div>
                  </td>
                  <td className="px-3 py-3 text-[12.5px] leading-relaxed text-[color:var(--ink-soft)]">
                    <span className="mono mr-1.5 rounded-[3px] bg-[color:var(--surface)] px-1 py-0.5 text-[9.5px] tracking-wide text-[color:var(--ink-soft)]">{CAT_LABEL[r.category]}</span>
                    {r.role}
                  </td>
                  <td className="mono px-3 py-3 text-[13px] font-medium">{r.stars.toLocaleString()}</td>
                  <td className="mono px-3 py-3 text-[12px]">
                    {r.lastPush}
                    <div className={`text-[10px] ${stale > 730 ? 'text-[#b3261e]' : stale > 365 ? 'text-[#6f7b74]' : 'text-[color:var(--accent)]'}`}>
                      {stale > 365 ? `${Math.floor(stale / 365)} 年前` : `${stale} 天前`}
                    </div>
                  </td>
                  <td className="mono px-3 py-3 text-[11.5px]">{r.license}</td>
                  <td className="px-3 py-3 text-[11.5px] text-[color:var(--ink-soft)]">{r.platforms}</td>
                  <td className="px-3 py-3"><StatusBadge status={r.status} /></td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <Para className="mt-6 max-w-[820px] text-[13px]">
        读表提示：star 数反映历史共识而非当前健康度——SCRecorder（3,037★）和 GPUImage 3（2,876★）都已实质停更；
        反之 Kadr（56★）与 Raster（11★）虽然数字寒酸，却是 2026 年仍在以周为单位提交的项目。
        对"持续维护"有硬要求的选型，应以最后提交时间和版本发布节奏为第一筛子，star 数只作为成熟度的辅助参考。
      </Para>
    </section>
  )
}
