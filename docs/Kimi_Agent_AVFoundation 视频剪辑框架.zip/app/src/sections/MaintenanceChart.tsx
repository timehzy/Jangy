import { useMemo } from 'react'
import { REPOS, TODAY } from '@/data/report'
import { Para, SectionMarker } from '@/components/shared'

const START = new Date('2013-01-01').getTime()
const END = new Date(TODAY).getTime()
const SPAN = END - START

function x(iso: string) {
  return ((new Date(iso).getTime() - START) / SPAN) * 100
}

const ROWS = [...REPOS].sort((a, b) => new Date(b.lastPush).getTime() - new Date(a.lastPush).getTime())

export default function MaintenanceChart() {
  const years = useMemo(() => {
    const ys: number[] = []
    for (let y = 2013; y <= 2026; y++) ys.push(y)
    return ys
  }, [])

  return (
    <section id="maintenance" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="05" zh="维护生命线" en="Maintenance Lifeline" />
      <Para className="mt-8 max-w-[820px]">
        每条横带代表一个仓库从创建到最后一次提交的生命周期，竖虚线是今天（2026-09-28）。
        带与虚线之间的空白，就是这个项目"已经沉默"的时间。<strong className="text-[color:var(--ink)]">蓝色带仍在生长，灰色带已经定格。</strong>
      </Para>

      <div className="reveal mt-8 overflow-x-auto border border-[color:var(--line-strong)] bg-[color:var(--paper)]">
        <div className="min-w-[860px] p-5">
          {/* 年份刻度 */}
          <div className="relative ml-[150px] h-5">
            {years.map((y) => (
              <span key={y} className="mono absolute -translate-x-1/2 text-[9.5px] text-[color:var(--ink-faint)]" style={{ left: `${x(`${y}-01-01`)}%` }}>
                {y}
              </span>
            ))}
          </div>
          <div className="relative">
            {/* 今日线 */}
            <div className="absolute bottom-0 top-0 w-px bg-[color:var(--accent)]" style={{ left: `calc(150px + (100% - 150px) * ${x(TODAY) / 100})` }}>
              <span className="mono absolute -top-1 left-1 whitespace-nowrap text-[9.5px] font-bold text-[color:var(--accent)]">TODAY</span>
            </div>
            {ROWS.map((r) => {
              const alive = r.status === 'active' || r.status === 'slow'
              const left = 150 + (860 - 150) * 0 // computed via percent inside track
              void left
              return (
                <div key={r.id} className="group flex items-center py-[5px]">
                  <div className="w-[150px] shrink-0 pr-3 text-right">
                    <span className="text-[12.5px] font-semibold">{r.name}</span>
                    <span className="mono ml-1.5 text-[9.5px] text-[color:var(--ink-faint)]">{r.stars >= 1000 ? `${(r.stars / 1000).toFixed(1)}k` : r.stars}★</span>
                  </div>
                  <div className="relative h-[14px] flex-1">
                    <div
                      className={`absolute top-0 h-full transition-all ${alive ? 'bg-[color:var(--accent)]' : 'bg-[rgba(35,31,32,0.28)]'} group-hover:opacity-80`}
                      style={{ left: `${x(r.created)}%`, width: `${Math.max(x(r.lastPush) - x(r.created), 0.6)}%` }}
                      title={`${r.created} → ${r.lastPush}`}
                    />
                    {r.status === 'sunset' && <div className="absolute top-0 h-full w-[2px] bg-[#b3261e]" style={{ left: `${x(r.lastPush)}%` }} />}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <Para className="mt-6 max-w-[820px]">
        图中有三个值得记住的时刻：<strong className="text-[color:var(--ink)]">2021 年</strong>，SCRecorder 与 VideoLab 先后定格，
        标志第一代（Objective-C）与第二代（Swift 4/5）剪辑框架相继退场；<strong className="text-[color:var(--ink)]">2025 年初</strong>，
        FFmpegKit 退役、PixelSDK 停服，商业/跨平台路线同时收缩；<strong className="text-[color:var(--ink)]">2026 年</strong>，
        Kadr、VideoEditorKit、Raster 三个 Swift 6 时代项目几乎同时出现——生态完成了一次换代。
        对维护性的判断不能只看"最后一次提交距今多久"，还要看项目是否处于其生命周期的上升段。
      </Para>
    </section>
  )
}
