const LINKS = [
  ['结论', '#verdict'],
  ['生态全景', '#landscape'],
  ['深度评析', '#deepdive'],
  ['Agent 亲和性', '#agent'],
  ['功能矩阵', '#matrix'],
  ['匹配计算', '#fit'],
  ['选型建议', '#recommendation'],
] as const

export default function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-[color:var(--line)] bg-[rgba(242,245,240,0.82)] backdrop-blur-md">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between px-5 py-3">
        <a href="#top" className="flex items-baseline gap-2">
          <span className="mono text-[12px] font-bold tracking-[0.2em] text-[color:var(--accent)]">AVF/REPORT</span>
          <span className="hidden sm:inline text-[13px] font-semibold">iOS 开源视频剪辑框架调研</span>
        </a>
        <nav className="flex items-center gap-4 md:gap-6 overflow-x-auto">
          {LINKS.map(([zh, href]) => (
            <a key={href} href={href} className="mono whitespace-nowrap text-[11px] tracking-[0.14em] text-[color:var(--ink-soft)] hover:text-[color:var(--accent)] transition-colors">
              {zh}
            </a>
          ))}
        </nav>
      </div>
    </header>
  )
}
