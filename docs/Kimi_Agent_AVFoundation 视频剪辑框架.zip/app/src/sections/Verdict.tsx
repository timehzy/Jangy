import { Para, SectionMarker } from '@/components/shared'

const CARDS = [
  {
    tag: '首选 · 面向未来',
    name: 'Kadr 全家桶',
    accent: true,
    body: '2026 年 4 月诞生、9 月已发 v1.1 的声明式视频合成框架：result-builder DSL + async/await + Swift 6 严格并发，零三方依赖。引擎（kadr）与 UI（kadr-ui）分包，字幕/音频/持久化/相册各有独立伴随包，几乎是为"UI 与逻辑分离"这条要求量身定做。代价：单作者、社区极小，需要接受"押注新秀"的风险并做好 fork 预案。',
  },
  {
    tag: '保守 · 可控',
    name: 'Cabbage（fork 维护）',
    accent: false,
    body: '2018 年诞生的经典时间线框架，Timeline / Resource / TrackItem 三层抽象干净利落，1.5k star 验证了设计共识。但 2023 年 11 月后无提交，Swift 4 时代代码，需自行接管维护并补齐滤镜（配 MetalPetal/Raster）与全部 UI。适合"完全掌控、不在乎自己养框架"的团队。',
  },
  {
    tag: '蓝本 · 不自用',
    name: 'VideoLab',
    accent: false,
    body: '架构设计上最有野心的一个：AE 式图层模型、Metal 自定义合成器、关键帧动画、预合成。但它停在 2022 年 10 月，变速功能始终躺在 TODO 里。正确用法是读它的设计文档当自研蓝本，而不是直接依赖。',
  },
] as const

export default function Verdict() {
  return (
    <section id="verdict" className="mx-auto max-w-[1200px] px-5 py-14">
      <SectionMarker no="01" zh="结论速览" en="Executive Summary" />
      <div className="mt-8">
        <Para className="max-w-[820px]">
          直接回答"有没有比较好的"：<strong className="text-[color:var(--ink)]">有，但没有银弹</strong>。
          纯开源 + AVFoundation + Swift + 持续维护四个条件取交集后，真正值得认真评估的只有四个：
          <strong className="text-[color:var(--ink)]">Kadr</strong>、<strong className="text-[color:var(--ink)]">Cabbage</strong>、
          <strong className="text-[color:var(--ink)]">VideoLab</strong>、<strong className="text-[color:var(--ink)]">VideoEditorKit</strong>。
          其中 Kadr 是唯一同时满足"持续维护、Swift 6 现代技术栈、引擎与 UI 分包、功能覆盖接近完整"的选项，
          也是本报告的首推；Cabbage 是经得起时间考验的保守底座；VideoLab 是最好的架构参考书。
        </Para>
      </div>
      <div className="mt-10 grid gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)] md:grid-cols-3">
        {CARDS.map((c, i) => (
          <article key={c.name} className={`reveal bg-[color:var(--paper)] p-6 ${c.accent ? 'relative' : ''}`} style={{ transitionDelay: `${i * 90}ms` }}>
            {c.accent && <span className="absolute right-4 top-4 mono text-[10px] tracking-[0.2em] text-[color:var(--accent)]">RECOMMENDED</span>}
            <div className="mono text-[10px] uppercase tracking-[0.22em] text-[color:var(--ink-faint)]">{c.tag}</div>
            <h3 className={`mt-2 text-[24px] font-black ${c.accent ? 'text-[color:var(--accent)]' : ''}`}>{c.name}</h3>
            <p className="mt-3 text-[13.5px] leading-[1.9] text-[color:var(--ink-soft)]">{c.body}</p>
          </article>
        ))}
      </div>
      <Para className="mt-8 max-w-[820px]">
        一个值得注意的时代背景：视频处理生态在 2025 年经历了一次"清场"——FFmpegKit 官方退役（2025-01）、
        PixelSDK 宣布停服（2025-02）、MetalPetal 作者失联后由社区 fork 出 Raster 接续（2026-08）。
        老牌选项大面积熄火的同一年，Kadr、VideoEditorKit 等 Swift 6 原生新框架开始冒头。
        此刻入场选型，本质上是在"成熟但停更"与"新锐但稚嫩"之间做权衡，本报告后面所有分析都围绕这个权衡展开。
      </Para>
      <Para className="mt-8 max-w-[820px]">
        两个新背景让结论进一步收敛：<strong className="text-[color:var(--ink)]">1-2 人的 side project</strong>意味着
        "fork 并长期自养一个停更框架"的隐性成本被放大——Cabbage 的 47 个 open issue 和 VideoLab 的 TODO 变速，
        在小团队手里都是真实的时间黑洞；<strong className="text-[color:var(--ink)]">未来要接入 AI 剪辑 Agent（CLI/MCP 化）</strong>意味着
        框架的"时间线表达方式"必须能被程序生成与序列化——一个只能被 UI 手势驱动的命令式 API，
        在 Agent 场景下等于不存在。在这两条约束下，Kadr 的优势从"领先"变成了"几乎唯一可选"：
        它的 result-builder DSL 本身就是一段可被 LLM 生成、可被 JSON 序列化、可在无 UI 环境下执行的代码。
      </Para>
    </section>
  )
}
