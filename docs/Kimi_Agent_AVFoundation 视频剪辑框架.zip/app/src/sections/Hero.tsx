export default function Hero() {
  return (
    <section id="top" className="mx-auto max-w-[1200px] px-5 pt-16 pb-14 md:pt-24 md:pb-20">
      <div className="reveal mono text-[11px] uppercase tracking-[0.28em] text-[color:var(--accent)]">
        Deep Research · 2026-09-28 · Apple Platform Video Editing
      </div>
      <h1 className="reveal mt-6 text-[40px] leading-[1.12] font-black tracking-tight md:text-[68px]">
        基于 AVFoundation 的<br />
        iOS 开源视频剪辑框架<span className="text-[color:var(--accent)]">选型调研</span>
      </h1>
      <div className="reveal mt-8 grid gap-8 md:grid-cols-[1.4fr_1fr]">
        <p className="text-[16px] leading-[2] text-[color:var(--ink-soft)]">
          目标：为一款 Apple 平台通用视频剪辑 App 寻找可作为底座的开源框架。要求覆盖多段裁剪、调色、滤镜、转场、
          BGM、变速、画幅调整、字幕、贴纸等完整功能链，且框架需架构清晰、UI 与逻辑分离、扩展性强、持续维护、
          Swift 技术栈。<strong className="text-[color:var(--ink)]">补充约束：1-2 人 side project 团队，未来需接入 AI 剪辑 Agent（CLI/MCP 化）。</strong>
          本报告调研了 GitHub 生态中 12 个候选仓库，核实其维护状态、架构设计与功能覆盖，并给出分层选型建议。
        </p>
        <div className="mono grid grid-cols-3 gap-px border border-[color:var(--line-strong)] bg-[color:var(--line-strong)] text-center">
          {[
            ['12', '候选仓库'],
            ['9+', '功能维度'],
            ['04', '核心候选'],
          ].map(([n, l]) => (
            <div key={l} className="bg-[color:var(--paper)] px-2 py-4">
              <div className="text-[26px] font-bold text-[color:var(--accent)]">{n}</div>
              <div className="mt-1 text-[10px] tracking-[0.15em] text-[color:var(--ink-faint)]">{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
